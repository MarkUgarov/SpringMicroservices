package de.adesso.adessibmarleyresilienceclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdessiBmarleyResilienceClientApplicationTests {

    @Test
    void contextLoads() {
    }

}
