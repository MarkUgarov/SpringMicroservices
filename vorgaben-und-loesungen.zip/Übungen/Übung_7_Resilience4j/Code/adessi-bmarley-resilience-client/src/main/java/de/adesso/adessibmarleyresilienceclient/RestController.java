package de.adesso.adessibmarleyresilienceclient;

import org.springframework.web.bind.annotation.GetMapping;

@org.springframework.web.bind.annotation.RestController
public class RestController {
    private final CcLeaderService service;

    public RestController(CcLeaderService service) {
        this.service = service;
    }

    @GetMapping("/ccleader")
    public String ccLeader() {
        return service.ccLeader();
    }
}
