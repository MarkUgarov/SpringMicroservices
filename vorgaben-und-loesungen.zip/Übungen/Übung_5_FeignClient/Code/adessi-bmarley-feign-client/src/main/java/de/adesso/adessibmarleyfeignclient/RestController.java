package de.adesso.adessibmarleyfeignclient;

import com.netflix.appinfo.InstanceInfo;
import com.netflix.discovery.EurekaClient;
import com.netflix.discovery.shared.Application;
import feign.Feign;
import org.springframework.cloud.openfeign.support.SpringMvcContract;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;
import java.util.stream.Collectors;

@org.springframework.web.bind.annotation.RestController
public class RestController {

    private final AdessiFeignInterface adessiService;

    private final EurekaClient eurekaClient;

    public RestController(AdessiFeignInterface adessiService, EurekaClient eurekaClient) {
        this.adessiService = adessiService;
        this.eurekaClient = eurekaClient;
    }

    @GetMapping("/services")
    public String getServices() {

        Application application = eurekaClient.getApplication("adessi-bmarley");
        List<InstanceInfo> instances = application.getInstances();

        return instances.stream()
                .map(instanceInfo -> instanceInfo.getHostName() + ":" + instanceInfo.getPort())
                .collect(Collectors.joining(" | "));
    }

    @GetMapping("/firstName")
    public String getFirstName() {
        AdessiFeignInterface feignClient = Feign.builder()
                .contract(new SpringMvcContract())
                .target(AdessiFeignInterface.class, "http://localhost:8091");

        return feignClient.getFirstName();

    }

    @GetMapping("/adessi")
    public String getTest2() {
        return adessiService.getFirstName() + " " +
                adessiService.getLastName() + " " +
                adessiService.getCompetenceCenter();
    }
}
