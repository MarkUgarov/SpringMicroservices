package de.adesso.adessibmarley;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdessiRestController implements de.adesso.adessi.AdessiRestInterface {

    private final Environment env;

    @Value("${course}")
    private String course;

    public AdessiRestController(Environment env) {
        this.env = env;
    }

    @Override
    public String getFirstName() {
        return "Bob";
    }

    @Override
    public String getLastName() {
        return "Marley";
    }

    @Override
    public String getLineOfBusiness() {
        return "HR";
    }

    @Override
    public String getCompetenceCenter() {
        return "HR-1 " + env.getProperty("local.server.port");
    }

    @Override
    public String getCompetenceCenterLeader() {
        return "Bob Marley";
    }

    @Override
    public String getJobDescription() {
        return "Feelgood Manager";
    }

    @GetMapping("/adessi/courseAttended")
    public String getCourseAttended() {
        return course;
    }

    @GetMapping("/")
    public String getRoot() {
        return "I am runnint on port: " + env.getProperty("local.server.port");
    }
}
