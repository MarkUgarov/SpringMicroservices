package de.adesso.adessibmarleyloadbalancerclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdessiBmarleyLoadbalancerClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdessiBmarleyLoadbalancerClientApplication.class, args);
	}

}
