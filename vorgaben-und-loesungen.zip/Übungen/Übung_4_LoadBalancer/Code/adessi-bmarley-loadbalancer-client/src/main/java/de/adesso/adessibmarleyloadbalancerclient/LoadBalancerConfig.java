package de.adesso.adessibmarleyloadbalancerclient;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class LoadBalancerConfig {

    @Bean
    @Primary
    public AdessiServiceInstanceListSupplier getAdessiServiceInstanceListSupplier() {
        return new AdessiServiceInstanceListSupplier("adessi");
    }

}
