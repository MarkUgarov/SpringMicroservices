package com.example.adessibmarleyapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdessiBmarleyApiGatewayApplicationTests {

    @Test
    void contextLoads() {
    }

}
