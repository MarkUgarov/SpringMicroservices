package de.adesso.adessibmarley;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdessiBmarleyApplication {

    public static void main(String[] args) {
        SpringApplication.run(AdessiBmarleyApplication.class, args);
    }

}
