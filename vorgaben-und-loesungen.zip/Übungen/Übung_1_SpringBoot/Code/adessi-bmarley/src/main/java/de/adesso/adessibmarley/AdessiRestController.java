package de.adesso.adessibmarley;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdessiRestController implements de.adesso.adessi.AdessiRestInterface {
    @Override
    public String getFirstName() {
        return "Bob";
    }

    @Override
    public String getLastName() {
        return "Marley";
    }

    @Override
    public String getLineOfBusiness() {
        return "HR";
    }

    @Override
    public String getCompetenceCenter() {
        return "HR-1";
    }

    @Override
    public String getCompetenceCenterLeader() {
        return "Bob Marley";
    }

    @Override
    public String getJobDescription() {
        return "Feelgood Manager";
    }
}
