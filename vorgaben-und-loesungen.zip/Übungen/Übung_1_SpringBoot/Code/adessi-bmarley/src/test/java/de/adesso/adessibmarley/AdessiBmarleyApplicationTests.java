package de.adesso.adessibmarley;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdessiBmarleyApplicationTests {

    @Test
    void contextLoads() {
    }

}
