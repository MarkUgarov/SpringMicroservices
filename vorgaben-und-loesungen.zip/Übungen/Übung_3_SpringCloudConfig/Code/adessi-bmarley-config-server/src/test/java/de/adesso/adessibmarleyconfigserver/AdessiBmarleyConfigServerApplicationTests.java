package de.adesso.adessibmarleyconfigserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdessiBmarleyConfigServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
